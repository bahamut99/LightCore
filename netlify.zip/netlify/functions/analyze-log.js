export async function handler(event, context) {
  return {
    statusCode: 200,
    body: "Hello from analyze-log!",
  };
}